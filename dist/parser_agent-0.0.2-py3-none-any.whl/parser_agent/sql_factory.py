from parser_agent.sql_create_query import CreateQuery
from parser_agent.sql_select_query import SelectQuery

from parser_agent.sql_query_miners import SelectQueryMiner


# Warning not tested
class SqlQueryFactory(object):

    def __init__(self):

        self._holders = {}

    def register_holder(self, _type, holder):

        self._holders[_type] = holder

    def get_holder(self, query, *args, **kwargs):

        _type=SelectQueryMiner().get_type(query)

        holder = self._holders.get(_type)

        if not holder:

            raise ValueError(_type)

        return holder(query, *args, **kwargs)


factory = SqlQueryFactory()
factory.register_holder('CREATE', CreateQuery)
factory.register_holder('SELECT', SelectQuery)