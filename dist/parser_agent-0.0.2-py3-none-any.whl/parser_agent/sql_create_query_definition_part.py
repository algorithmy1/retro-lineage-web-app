from parser_agent.sql_query_part import QueryPart
from parser_agent.sql_query_miners import CreateQueryMiner


class CreateQueryDefinition(QueryPart):

    def __init__(self, query_part, query_group_name=""):

        super().__init__(query_part=query_part)

        self.table_name=None

        self.table_property=None

        self.query_group_name = query_group_name
    
    def mine(self):

        self.table_name = CreateQueryMiner().mine_name_of_create_query_table(self.query_part)

        self.table_property = CreateQueryMiner().mine_type_of_create_query_table(self.query_part)

        return self
    
    def to_dash_elements(self, with_parent=True, output_query=""):
        
        data = dict()

        _id=""
        label=""
        query=""
        classes=""
        parent=self.query_group_name

        #if self.query_group_name :
        #    _id = f"{self.query_group_name}"
        
        #_id = f"{_id}.{self.table_name}.{self.table_name}"

        _id = f"{self.table_name}"

        label = f"{self.table_name}"

        query=output_query

        data={
            'id' : _id,
            'label' : label,
            'query' : query,
        }

        if with_parent:
            data['parent']=parent

        classes=self.table_property

        return [{
            'data' : data,
            'classes': classes
        }]




        