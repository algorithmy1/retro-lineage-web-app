from parser_agent.sql_statement import DmlQuery
from parser_agent.sql_query_miners import SelectQueryMiner
from parser_agent.sql_select_query_parser import SelectQueryParser

import moz_sql_parser

class SelectQuery(DmlQuery):

    def __init__(self, query="", name="", _property="", final_output_table=""):

        super().__init__(query=query)

        self.name = name

        self.property = _property

        self.final_output_table=final_output_table

        self._select = None

        self._from = None

        self._where = None

        self._group_by = None

        self._having = None

        self._order_by = None

        self._input_tables = None

        self._from_nested_queries = None

        self._where_nested_queries = None
    
    @property
    def is_select(self):

        return SelectQueryMiner().is_select_query(self.query)
    
    @property
    def is_nested(self):

        if self._from_nested_queries or self._where_nested_queries :

            return True

        return False


    
    def set_tree(self):

        # Warning not tested

        self._tree = SelectQueryParser().parse_n_normalize(self.query)

        return self
    
    def split_tree(self):

        self._select = self._tree.get("select", [])

        self._from = self._tree.get("from", [])

        self._where = self._tree.get("where", [])

        self._group_by = []

        self._having = []

        self._order_by = []

        return self

    def find_input_tables(self):

        def get_deeper(element, name=""): # for from clause

            if isinstance(element, str):

                self._input_tables.append(element)
            
            elif isinstance(element, dict):
                
                if 'value' in element :

                    get_deeper(
                        element['value'][0],
                        element.get('name', [""])[0]
                    )
                
                elif 'select' in element :

                    temp_query = moz_sql_parser.format(element)

                    self._from_nested_queries.append(
                            SelectQuery(temp_query, name).mine()
                        )
                
                elif 'join' in list(element.keys())[0]:

                    join=list(element.keys())[0]

                    get_deeper(element[join][0])
                
                else :

                    raise Exception(f"Unexpexted dict : {element}")
            
            else :

                raise Exception(f"Unexpected type : {type(element)}")

        def get_inside(element): # for where clause

            if isinstance(element, (str, int, float)):

                pass
            
            elif isinstance(element, list):

                for e in element :

                    get_inside(e)
            
            elif isinstance(element, dict):

                if 'select' in element :

                    temp_query = moz_sql_parser.format(element)

                    self._where_nested_queries.append(
                        SelectQuery(temp_query).mine()
                    )
                
                else :

                    for k,v in element.items():

                        get_inside(v)
                    
            else :

                raise Exception(f"Unexpected type : {type(element)}")

        self._input_tables = []

        self._from_nested_queries = []

        self._where_nested_queries = []

        for group in self._from:

            get_deeper(group)
        
        get_inside(self._where)
        
        return self
    
    def mine(self):

        self.set_tree().split_tree().find_input_tables()

        return self
    
    @property
    def all_input_tables(self):

        _all=[]

        if self._input_tables :

            _all += self._input_tables
        
        if self.is_nested :

            if self._from_nested_queries :

                for q in self._from_nested_queries :

                    _all += q.all_input_tables
            
            if self._where_nested_queries :

                for q in self._where_nested_queries :

                    _all += q.all_input_tables
    
        return _all
    
    @property
    def all_input_tables_with_origin(self):

        _all=[]

        if self._input_tables :

            _all += [{"name" : table, "link_type" : "DIRECT" } for table in self._input_tables]
        
        if self.is_nested :

            if self._from_nested_queries :

                for q in self._from_nested_queries :

                    _all +=  [{"name" : table, "link_type" : "NESTED_FROM" } for table in q.all_input_tables] 
            
            if self._where_nested_queries :

                for q in self._where_nested_queries :

                   _all +=  [{"name" : table, "link_type" : "NESTED_WHERE" } for table in q.all_input_tables]
    
        return _all
    
    def to_dash_elements(self,\
            with_parent=True, \
            intermediate_tables=[], \
            query_group_name="", \
            target_id=""
        ):
        
        data = list()

        all_tables= self.all_input_tables_with_origin

        for table_as_dict in all_tables:

            _id=""
            label=table_as_dict["name"]

            if table_as_dict["name"].upper() in intermediate_tables:
                classes="INTERMEDIATE"
            else :
                classes="INPUT"
            
            parent=query_group_name

            if classes=="INPUT":
                _id = f"{label}"
            
            else:
                if parent :
                    _id = f"{parent}"
                
                _id = f"{_id}.{self.final_output_table}.{label}"

            _data={
                'id' : _id,
                'label' : label,
                'query': 'Source table'
            }

            if with_parent and classes!="INPUT":
                _data['parent']=parent
            
            if classes != 'INTERMEDIATE' :

                data +=[
                    {
                        'data' : _data,
                        'classes': classes
                    }
                ]

            data += [
                {
                    'data': {
                        'source': _id,
                        'target': target_id
                    },
                    'classes': table_as_dict["link_type"]
                }
                
            ]

        return data













        
    
