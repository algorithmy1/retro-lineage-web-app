

class SqlStatement(object):

    def __init__(self, query=""):

        self.query=query
    
    def __repr__(self):

        return self.query


class DdlQuery(SqlStatement):

    def __init__(self, query=""):

        super().__init__(query=query)

class DmlQuery(SqlStatement):

    def __init__(self, query=""):

        super().__init__(query=query)
    
class OtherQuery(SqlStatement):

    def __init__(self, query=""):

        super().__init__(query=query)