
import sqlparse


class SqlQuerySplitters(object):
    
    def split_statemenes(self, sql_query):
        """
        This function splits a query into statements:
        exples: 'SELECT A from B; SELECT C from D; CREATE ...' => ['SELECT A from B', 'SELECT C from D', 'CREATE ...']
        """

        statements = sqlparse.parse(sql_query)

        splitted = [statement.value.strip() for statement in statements]

        return splitted
    
    def split_create_query(self, sql_query):
        """
        This function splits a create query into 3 parts:
        exple: 
        '''CREATE TEMPORARY TABLE C
        AS
        WITH base AS (SELECT A FROM B), agg AS (SELECT A FROM base)
        SELECT * FROM agg
        '''
        => [
            "CREATE TEMPORARY TABLE C",
            "base AS (SELECT A FROM B), agg AS (SELECT A FROM base)",
            "SELECT * FROM agg"
        ]
        """
        _ = None

        try:
            _ = sqlparse.parse(sql_query.strip())
        
        except:
            # To-Do
            pass
        
        if not _ :

            raise ValueError(f"Query error : {sql_query}")

        parsed_query = _[0]

        as_pos = None
        as_found=False
        select_found=False

        for i, element in enumerate(parsed_query.tokens):

            if not as_found:

                if element.ttype==sqlparse.tokens.Keyword and element.value.upper()=='AS':

                    as_pos = i
                    as_found = True
            else:

                if element.ttype==sqlparse.tokens.Keyword.DML and element.value.upper()=="SELECT":

                    select_pos = i
                    select_found = True
                    break

        if not as_pos :
            # Not tested yet
            raise ValueError(f"AS not found in CREATE query : {sql_query}")
            
        if not select_pos :
            # Not tested yet
            raise ValueError(f"SELECT not found in CREATE query : {sql_query}")   
        
        definition_query = (sqlparse.sql.Statement(parsed_query.tokens[:as_pos]).value).strip()
        intermediate_tables_query =  (sqlparse.sql.Statement(parsed_query.tokens[as_pos+1:select_pos]).value).strip()
        table_query =  (sqlparse.sql.Statement(parsed_query.tokens[select_pos:]).value).strip()

        return [
            definition_query,
            intermediate_tables_query,
            table_query
        ]