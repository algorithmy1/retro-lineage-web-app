from parser_agent.sql_query_part import QueryPart
from parser_agent.sql_select_query import SelectQuery


class CreateQueryOutput(QueryPart):

    # Warning Not tested
    
    def __init__(self, query_part, output_table_name ="", query_group_name=""):

        super().__init__(query_part=query_part)

        self.query_group_name=query_group_name

        self.select_as_object = SelectQuery(query_part, final_output_table=output_table_name)

    
    def mine(self):

        self.select_as_object.mine()

        return self
    
    def to_dash_elements(self, with_parent=True, intermediate_tables=[], target_id=""):
        # Warning not tested but almost nothing to test.

        # print("##", target_id)
        return self.select_as_object.to_dash_elements(\
            with_parent=with_parent, \
            intermediate_tables=intermediate_tables, \
            query_group_name=self.query_group_name,\
            target_id=target_id
        )