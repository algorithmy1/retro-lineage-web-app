import sqlparse

from sqlparse.tokens import Keyword, DML, DDL

from parser_agent.sql_query_cleaners import SqlQueryCleaners
from parser_agent.sql_table import SqlTable
from parser_agent.sql_graph import SqlGraph
from parser_agent.sql_select_query_parser import SelectQueryParser
"""
This module intends to transform a query into a directed graph
"""
class SqlQueryMiner(object):

    def get_type(self, query):

        if not query :

            return None

        statement = sqlparse.parse(query)[0] # Warning : Et s'il y'a plus d'une requete.

        _type = statement.get_type()

        if "CREATE" in statement.get_type().upper():

            return "CREATE"

        return _type

class CreateQueryMiner(SqlQueryMiner):

    def is_create_query(self, query):

        return self.get_type(query) == 'CREATE'

    def mine_type_of_create_query_table(self, definition_query):

        if not definition_query :

            return ""

        type_="PERMANENT"
        
        for element in sqlparse.parse(definition_query)[0].tokens:

            if element.ttype==sqlparse.tokens.Keyword:
                if (\
                    element.value.upper()=='TEMPORARY' or element.value.upper()=='TEMP' \
                ) :

                    type_="TEMPORARY"
                    break;

                elif element.value.upper()=='VIEW':
                    
                    type_="VIEW"
                    break;

        
        return type_
    
    def mine_name_of_create_query_table(self, definition_query):
        
        if not definition_query:

            return ""

        name = ""

        for element in sqlparse.parse(definition_query)[0].tokens:
            
            if isinstance(element, sqlparse.sql.Identifier):

                identifier = element

                name = identifier.value.split()[0]

                break;
        
        
        
        return name
    
    def mine_create_intermediate_tables_query(self, intermediate_tables_query):

        intermediate_tables_dict = dict()

        if not intermediate_tables_query : 
            
            return intermediate_tables_dict
        
        _parsed = sqlparse.parse(intermediate_tables_query.strip())[0].tokens[-1]

        if isinstance(_parsed, sqlparse.sql.IdentifierList) :

            for element in _parsed.tokens:

                if isinstance(element, sqlparse.sql.Identifier):

                    name=element.tokens[0].value.strip()
                    query=element.tokens[-1].value
                    query=SqlQueryCleaners().clean_parentheses(query)

                    intermediate_tables_dict[name]=query
        
        elif isinstance(_parsed, sqlparse.sql.Identifier) :

            name=_parsed.tokens[0].value.strip()
            query=_parsed.tokens[-1].value
            query=SqlQueryCleaners().clean_parentheses(query)
            
            intermediate_tables_dict[name]=query
        
        else : 
            raise Exception("Unexpexted block type in intermediateCreateQueryMiner")


        
        return intermediate_tables_dict

class SelectQueryMiner(SqlQueryMiner):

    def is_select_query(self, query):
                
        return self.get_type(query) == 'SELECT'
    
    def is_set_operation(self, query):
        
        
        parsed = SelectQueryParser().parse(query)

        if 'union' in parsed or 'union_all' in parsed:
            # INTERSECT and MINUS mission !!

            return True
        
        return False

    def find_input_tables_of_non_nested_query(self, query):

        pass