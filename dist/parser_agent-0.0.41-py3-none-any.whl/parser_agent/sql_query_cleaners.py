import sqlparse


class SqlQueryCleaners(object):
    """
    This is a tool class to clean queries
    """
    
    def uncomment(self, sql_query):
        """
        This method clean query from comments
        """
        return sqlparse.format(sql_query, strip_comments=True).strip()

    def clean_parentheses(self, query):
        """
        This method cleans parentheses
        """
        original_query = query

        if isinstance(query, str):

            try :

                _ = sqlparse.parse(query.strip())[0].tokens[0]

                query = _

            except:

                return query

        
        if isinstance(query, sqlparse.sql.Parenthesis):

            return query.value.strip()[1:-1].strip()
        
        return original_query
