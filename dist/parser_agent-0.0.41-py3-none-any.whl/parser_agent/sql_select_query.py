from typing import overload
from parser_agent.sql_statement import DmlQuery
from parser_agent.sql_query_miners import SelectQueryMiner
from parser_agent.sql_select_query_parser import SelectQueryParser
from parser_agent.sql_table_id_generator import SqlTableIdGenerator


import moz_sql_parser


class SelectQueryUnit(DmlQuery):

    # UNION or INTERSECT operations are not allowed in this class check the class before
    # This class is not tested independently but SelectQuery is tested

    def __init__(self, query="", name="", _property="", final_output_table=""):

        super().__init__(query=query)

        self.name = name

        self.property = _property

        self.final_output_table=final_output_table

        self._select = None

        self._from = None

        self._where = None

        self._group_by = None

        self._having = None

        self._order_by = None

        self._input_tables = None

        self._from_nested_queries = None

        self._where_nested_queries = None
    
    @property
    def is_select(self):

        return SelectQueryMiner().is_select_query(self.query)
    
    @property
    def is_set_operation(self):

        return SelectQueryMiner().is_set_operation(self.query)
    
    @property
    def is_nested(self):

        if self._from_nested_queries or self._where_nested_queries :

            return True

        return False
 
    def set_tree(self):

        # Warning not tested

        self._tree = SelectQueryParser().parse_n_normalize(self.query)

        return self
    
    def split_tree(self):

        self._select = self._tree.get("select", [])

        self._from = self._tree.get("from", [])

        self._where = self._tree.get("where", [])

        self._group_by = []

        self._having = []

        self._order_by = []

        return self

    def find_input_tables(self):

        def get_deeper(element, name=""): # for from clause

            if isinstance(element, str):

                self._input_tables.append(element)
            
            elif isinstance(element, dict):
                
                if 'value' in element :

                    get_deeper(
                        element['value'][0],
                        element.get('name', [""])[0]
                    )
                
                elif 'select' in element or 'union' in element or 'union_all' in element:

                    temp_query = moz_sql_parser.format(element)

                    self._from_nested_queries.append(
                            SelectQuery(temp_query, name).mine()
                        )
                
                elif 'join' in list(element.keys())[0]:

                    join=list(element.keys())[0]

                    get_deeper(element[join][0])
                
                else :

                    raise Exception(f"Unexpexted dict : {element}")
            
            else :

                raise Exception(f"Unexpected type : {type(element)}")

        def get_inside(element): # for where clause

            if isinstance(element, (str, int, float)):

                pass
            
            elif isinstance(element, list):

                for e in element :

                    get_inside(e)
            
            elif isinstance(element, dict):

                if 'select' in element or 'union' in element or 'union_all' in element:


                    temp_query = moz_sql_parser.format(element)

                    self._where_nested_queries.append(
                        SelectQuery(temp_query).mine()
                    )
                
                else :

                    for k,v in element.items():

                        get_inside(v)
                    
            else :

                raise Exception(f"Unexpected type : {type(element)}")

        self._input_tables = []

        self._from_nested_queries = []

        self._where_nested_queries = []

        for group in self._from:

            get_deeper(group)
        
        get_inside(self._where)
        
        return self
    
    def mine(self):

        self.set_tree().split_tree().find_input_tables()

        return self
    
    @property
    def all_input_tables(self):

        _all=[]

        if self._input_tables :

            _all += self._input_tables
        
        if self.is_nested :

            if self._from_nested_queries :

                for q in self._from_nested_queries :

                    _all += q.all_input_tables
            
            if self._where_nested_queries :

                for q in self._where_nested_queries :

                    _all += q.all_input_tables
    
        return _all
    
    @property
    def all_input_tables_with_origin(self):

        _all=[]

        if self._input_tables :

            _all += [{"name" : table, "link_type" : "DIRECT" } for table in self._input_tables]
        
        if self.is_nested :

            if self._from_nested_queries :

                for q in self._from_nested_queries :

                    _all +=  [{"name" : table, "link_type" : "NESTED_FROM" } for table in q.all_input_tables] 
            
            if self._where_nested_queries :

                for q in self._where_nested_queries :

                   _all +=  [{"name" : table, "link_type" : "NESTED_WHERE" } for table in q.all_input_tables]
    
        return _all
    
    def to_dash_elements(self,\
            with_parent=True, \
            intermediate_tables=[], \
            query_group_name="", \
            target_id=""
        ):
        
        data = list()

        all_tables= self.all_input_tables_with_origin

        for table_as_dict in all_tables:

            _id=""
            label=table_as_dict["name"]

            if table_as_dict["name"].upper() in intermediate_tables:
                classes="INTERMEDIATE"
            else :
                classes="INPUT"
            
            parent=query_group_name

            if classes=="INPUT":
                _id = f"{label}"
            
            else:
                if parent :
                    _id = f"{parent}"
                
                _id = f"{_id}.{self.final_output_table}.{label}"
            
            _id = SqlTableIdGenerator().generate(table_name=label, class_name=classes, group_name=parent, output_table_name=self.final_output_table)

            _data={
                'id' : _id,
                'label' : label,
                'query': 'Source table'
            }

            if with_parent and classes!="INPUT":
                _data['parent']=parent
            
            if classes != 'INTERMEDIATE' :

                data +=[
                    {
                        'data' : _data,
                        'classes': classes
                    }
                ]

            data += [
                {
                    'data': {
                        'source': _id,
                        'target': target_id
                    },
                    'classes': table_as_dict["link_type"]
                }
                
            ]

        return data




class SelectQuery(SelectQueryUnit):

    def __init__(self, query="", name="", _property="", final_output_table=""):

        super().__init__(query=query)

        self.name = name

        self.property = _property

        self.final_output_table=final_output_table

        if self.is_select:

            self.sub_queries_as_object = [
                SelectQueryUnit(query=query, name=name, _property=_property, final_output_table=final_output_table)
                for query in self.get_sub_set_queries()
            ]
        
    def get_sub_set_queries(self):
        # Extract sub queries in union and union_all case

        if self.is_select:

            self._tree = SelectQueryParser().parse_n_normalize(self.query)

        if self.is_select and not self.is_set_operation :

            return [self.query.strip()]
        

        queries = self._tree.values()
        
        if len(queries) != 1 :

            raise ValueError(f"Check the set of queries : {queries}")
        
        queries_str = [moz_sql_parser.format(x) for x in list(queries)[0]]

        return list(queries_str)
    
    
    def set_tree(self):

        for q in self.sub_queries_as_object:

            q.set_tree()

        return self
    
    def split_tree(self):

        for q in self.sub_queries_as_object:

            q.split_tree()
        
        return self

    
    def find_input_tables(self):

        self._input_tables = []

        for q in self.sub_queries_as_object:

            self._input_tables += q.find_input_tables()._input_tables
        
        # Not sorted Not deduplicated

        return self
    
    @property
    def all_input_tables(self):

        _all = []

        for q in self.sub_queries_as_object:

            _all += q.all_input_tables

        return _all

    @property
    def all_input_tables_with_origin(self):

        _all = []

        for q in self.sub_queries_as_object:

            _all += q.all_input_tables_with_origin

        return _all
    
    @property
    def is_nested(self):
        for q in self.sub_queries_as_object:

            if q.is_nested :
                
                return True
        
        return False
    
    """
    def mine(self):
        
        for q in self.sub_queries_as_object:
            
            q.set_tree().split_tree().find_input_tables()

        return self
    """

        
    
