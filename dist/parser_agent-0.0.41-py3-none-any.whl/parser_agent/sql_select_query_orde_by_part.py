from parser_agent.sql_query_part import QueryPart
from parser_agent.sql_query_miners import CreateQueryMiner


class SelectQueryeOrderByPart(QueryPart):

    def __init__(self, query_part):

        super().__init__(query_part=query_part)