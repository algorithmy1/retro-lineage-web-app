
class SqlGraph(object):
    """
    The representation of an sql query as a directed graph
    """

    def __init__(self, query=""):

        self.query=query
    
        self.graph=dict()

        self.tables=dict()
    
    def is_valid_query(self):
        
        return True
    
    def make(self):

        if self.is_valid_query():
        
            raise ValueError(f"Unvalid query : {self.query}")
        

        

