from parser_agent.sql_statement import DdlQuery
from parser_agent.sql_query_splitters import SqlQuerySplitters
from parser_agent.sql_query_miners import CreateQueryMiner
from parser_agent.sql_create_query_definition_part import CreateQueryDefinition
from parser_agent.sql_create_query_intermediates_part import CreateQueryIntermediates
from parser_agent.sql_create_query_output_part import CreateQueryOutput

class CreateQuery(DdlQuery):

    def __init__(self, query="", query_group_name=""):

        super().__init__(query=query)

        self.query_group_name = query_group_name

        self.definition_query = None
        self.intermediates_query = None
        self.output_query = None

        self.definition_part = None
        self.intermediates_part = None
        self.output_part = None

    @property
    def is_create(self):

        return CreateQueryMiner().is_create_query(self.query)
    
    def split_to_parts(self):
        """
        This function splits a create query into 3 parts:
        exple: 
        '''CREATE TEMPORARY TABLE C
        AS
        WITH base AS (SELECT A FROM B), agg AS (SELECT A FROM base)
        SELECT * FROM agg
        '''
        => [
            "CREATE TEMPORARY TABLE C",
            "base AS (SELECT A FROM B), agg AS (SELECT A FROM base)",
            "SELECT * FROM agg"
        ]
        """

        self.definition_query, self.intermediates_query, self.output_query = SqlQuerySplitters().split_create_query(self.query)

        return self
    

    
    def mine_parts(self):

        self.definition_part = CreateQueryDefinition(self.definition_query, \
            self.query_group_name).mine()

        self.intermediates_part = CreateQueryIntermediates(self.intermediates_query, \
            self.query_group_name, self.definition_part.table_name).mine()

        self.output_part = CreateQueryOutput(self.output_query, \
            output_table_name=self.definition_part.table_name, \
            query_group_name=self.query_group_name).mine()

        return self

    def mine(self):

        if not self.query :
            return self

        if not self.is_create:
            raise ValueError(f"The query is not a CREATE query : {self.query} \nYou might want to use SelectQuery class.")

        self.split_to_parts()\
            .mine_parts()
        
        return self
    
    def get_all_tables(self):

        _all_tables = []

        _all_tables += [self.definition_part.table_name]
        
        for q in self.intermediates_part.queries_as_objects :

            _all_tables += q.all_input_tables + [q.name]

        _all_tables += self.output_part.select_as_object.all_input_tables

        return list(set(_all_tables))
    
    def make_simple_tree(self):
        """
        {
            "output_table" : ["input_tqble_1", "input_table_2", ...],
        }
        
        """

        _tree = dict()

        if not self.definition_part : # or ...
            return _tree

        _tree[self.definition_part.table_name] = self.output_part.select_as_object.all_input_tables
        
        for p in self.intermediates_part.queries_as_objects :

            _tree[p.name] = p.all_input_tables

        return _tree
    
    def _to_dash(self, with_parent=True):

        _data=list()
        already_in_ids=[]

        if not self.definition_part : # or ...
            return _data

        _intermediate_tables=list(self.intermediates_part.queries_dict.keys())
        _intermediate_tables = [x.upper() for x in _intermediate_tables]

        _data += self.definition_part.to_dash_elements(with_parent=with_parent, \
             output_query=self.output_query
        )

        _data += self.intermediates_part.to_dash_elements(with_parent=with_parent)

        _data += self.output_part.to_dash_elements(with_parent=with_parent, \
            intermediate_tables=_intermediate_tables,\
            target_id=_data[0]['data']['id'] \
        )

        if with_parent:

            _data+=[
                {
                    'data': {
                        'id': self.query_group_name, 
                        'label': self.query_group_name
                    }

                }
            ]

        return _data
    
    def to_dash(self, with_parent=True):

        if not self.definition_part : # or ...
            return dict()

        return self._to_dash(with_parent=with_parent)
    
    def to_dash_with_parent(self):

        if not self.definition_part : # or ...
            return dict()

        prefix = self.definition_part.table_name

        if self.query_group_name:

            prefix = ".".join(
                [prefix, self.query_group_name]
            )

        _map = {table : [table, "INPUT"] for table in self.output_part.select_as_object.all_input_tables} # Sort for testing
        
        for s in self.intermediates_part.queries_as_objects:

            _map.update({table : [table, "INPUT"] for table in s.all_input_tables })

        _map.update({o.name : [".".join([prefix, o.name]), o.property] for o in self.intermediates_part.queries_as_objects})

        '''_map.update(
            {
                table :  [".".join([prefix, table.name]), table.property ]  for table in self.intermediates_part.queries_as_objects
            }
        )'''

        if self.definition_part.table_property == "TEMPORARY" :

             _map.update({self.definition_part.table_name : [".".join([prefix, self.definition_part.table_name]),"TEMPORARY"]})
        
        else :

            _map.update({self.definition_part.table_name : [self.definition_part.table_name, "PERMANENT"]})

        _tree= self.make_simple_tree()

        _data = [
            {
                'data': {
                    'id': _map[x][0],
                    'label': x if len(x)<=19 else x[:19],
                    #'parent': self.query_group_name,
                    
                },
                'classes' : _map[x][1]
            } for x in _map.keys()
        ]

        #_data += [{'data': { 'id': self.query_group_name, 'label': self.query_group_name}}]

        for _output, _inputs in _tree.items():
            
            for _input in _inputs :
                _data += [
                    {'data': {'source': _map[_input][0], 'target': _map[_output][0]}},
                ]
        
        # print('---->', _map)

        return _data





        