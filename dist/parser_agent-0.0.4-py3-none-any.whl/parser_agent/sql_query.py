from parser_agent.sql_query_splitters import SqlQuerySplitters 
from parser_agent.sql_query_miners import SelectQueryMiner
from parser_agent.sql_factory import factory
from parser_agent.sql_query_cleaners import SqlQueryCleaners

class SqlQuery(object):

    def __init__(self, query="", queries_group_name=""):

        self.query=query

        self.queries_group_name = queries_group_name
        
        self.queries = None

        self.queries_as_objects = None
    
    def __repr__(self):

        return self.query
    
    def clean(self):

        self.query=SqlQueryCleaners().uncomment(self.query)

        return self
    
    def split_to_statements(self):

        self.queries = SqlQuerySplitters().split_statemenes(self.query)

        return self
    
    def split(self):

        return self.split_to_statements()
    
    def filter_statements(self, list_to_keep=None):

        if list_to_keep == None :

            list_to_keep = ["CREATE"]
        
        # Warning : Check if list_to_keep is correct> 
        
        self.queries = [query for query in self.queries if SelectQueryMiner().get_type(query) in list_to_keep]

        return self
    
    def filter(self, list_to_keep=None):

        return self.filter_statements()
    
    def mine_statements(self):

        # Warning Not tested

        self.queries_as_objects = []

        for query in self.queries :

           self.queries_as_objects.append(factory.get_holder(query, self.queries_group_name).mine())

            # Warning : Class not defined !
    
    def mine(self):

        self.clean().split_to_statements().filter_statements().mine_statements()

        return self

    
    def to_dash(self, with_parent=True):

        _data = []

        for q in self.queries_as_objects :

            if q.is_create:

                _data += q.to_dash(with_parent)
        
        return _data