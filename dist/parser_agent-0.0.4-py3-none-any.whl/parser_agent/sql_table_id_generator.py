
class SqlTableIdGenerator(object):

    def __init__(self, rules=None) -> None:

        self.rules=rules
    
    def generate(self, table_name, class_name, group_name=None, output_table_name=None):
        
        if not (table_name or class_name):

            raise ValueError("table_name or class_name might be blank")

        if class_name in ["INPUT", "TEMPORARY", "PERMANENT", "VIEW"]:

            return table_name
        
        elif class_name in "INTERMEDIATE":

            _id=""

            if group_name :  _id=f"{group_name}."

            if output_table_name : _id=f"{_id}{output_table_name}."

            _id = f"{_id}{table_name}"

            return _id
        
        else :
            
            raise ValueError(f"Unknown class_name type : {class_name}")

        




