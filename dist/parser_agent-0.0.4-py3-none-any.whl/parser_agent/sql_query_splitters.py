
import sqlparse
import re


class SqlQuerySplitters(object):
    
    def split_statemenes(self, sql_query):
        """
        This function splits a query into statements:
        exples: 'SELECT A from B; SELECT C from D; CREATE ...' => ['SELECT A from B', 'SELECT C from D', 'CREATE ...']
        """

        statements = sqlparse.parse(sql_query)

        splitted = [statement.value.strip() for statement in statements]

        return splitted
    
    def split_create_query_v1(self, sql_query):
        """
        This function splits a create query into 3 parts:
        exple: 
        '''CREATE TEMPORARY TABLE C
        AS
        WITH base AS (SELECT A FROM B), agg AS (SELECT A FROM base)
        SELECT * FROM agg
        '''
        => [
            "CREATE TEMPORARY TABLE C",
            "base AS (SELECT A FROM B), agg AS (SELECT A FROM base)",
            "SELECT * FROM agg"
        ]
        """
        _ = None

        try:
            _ = sqlparse.parse(sql_query.strip())
        
        except:
            # To-Do
            pass
        
        if not _ :

            raise ValueError(f"Query error : {sql_query}")

        parsed_query = _[0]

        as_pos = None
        as_found=False
        select_found=False

        for i, element in enumerate(parsed_query.tokens):

            if not as_found:

                if element.ttype==sqlparse.tokens.Keyword and element.value.upper()=='AS':

                    as_pos = i
                    as_found = True
            else:

                if element.ttype==sqlparse.tokens.Keyword.DML and element.value.upper()=="SELECT":

                    select_pos = i
                    select_found = True
                    break

        if not as_pos :
            # Not tested yet
            raise ValueError(f"AS not found in CREATE query : {sql_query}")
            
        if not select_pos :
            # Not tested yet
            raise ValueError(f"SELECT not found in CREATE query : {sql_query}")   
        
        definition_query = (sqlparse.sql.Statement(parsed_query.tokens[:as_pos]).value).strip()
        intermediate_tables_query =  (sqlparse.sql.Statement(parsed_query.tokens[as_pos+1:select_pos]).value).strip()
        table_query =  (sqlparse.sql.Statement(parsed_query.tokens[select_pos:]).value).strip()

        return [
            definition_query,
            intermediate_tables_query,
            table_query
        ]

    def split_create_query(self, sql_query):
        """
        This function splits a create query into 3 parts:
        exple: 
        '''CREATE TEMPORARY TABLE C
        AS
        WITH base AS (SELECT A FROM B), agg AS (SELECT A FROM base)
        SELECT * FROM agg
        '''
        => [
            "CREATE TEMPORARY TABLE C",
            "base AS (SELECT A FROM B), agg AS (SELECT A FROM base)",
            "SELECT * FROM agg"
        ]
        """
        # Next 15 lines : Check that the query is parsable

        _ = None

        try:
            _ = sqlparse.parse(sql_query.strip())
        
        except:
            # To-Do
            pass
        
        if not _ :

            raise ValueError(f"Query error : {sql_query}")

        parsed_query = _[0]

        # Next 12 lines : Extract definition part

        AS_search = re.search(r"\bAS\b", parsed_query.value, flags=re.IGNORECASE)
        SELECT_search = re.search(r"\bSELECT\b", parsed_query.value, flags=re.IGNORECASE)

        if AS_search : AS_str_pos = AS_search.start()
        if SELECT_search : SELECT_str_pos = SELECT_search.start()

        if SELECT_str_pos < AS_str_pos or not AS_search :
            
            raise ValueError(f"AS not found in CREATE query : {sql_query}\nMore infos : _1st_SELECT_str_pos={SELECT_str_pos}, _1st_AS_str_pos={AS_str_pos}")

        definition_query = parsed_query.value[:AS_str_pos].strip()
        rest_of_the_query = parsed_query.value[AS_str_pos+2:].strip()

        # Next 3 lines : Erease ";" from the end of the query
        if rest_of_the_query[-1] ==";":

            rest_of_the_query=rest_of_the_query[:-1]

        # Until the end : Split to Intermediates tables and and final part of the query
        
        parsed_rest_of_the_query = sqlparse.parse(rest_of_the_query.strip())[0].tokens

        if isinstance(parsed_rest_of_the_query[-1], sqlparse.sql.Parenthesis):

            intermediate_tables_query = (sqlparse.sql.Statement(parsed_rest_of_the_query[:-1]).value).strip()

            table_query = (sqlparse.sql.Statement(parsed_rest_of_the_query[-1]).value[1:-1]).strip()

        else :

            select_found=False
            select_pos=None

            for i, element in enumerate(parsed_rest_of_the_query):

                if element.ttype==sqlparse.tokens.Keyword.DML and element.value.upper()=="SELECT":

                    select_pos = i
                    select_found = True
                    break
            
            if not select_found :

                raise ValueError(f"SELECT not found in CREATE query : {sql_query}")

            intermediate_tables_query =  (sqlparse.sql.Statement(parsed_rest_of_the_query[:select_pos]).value).strip()
            
            table_query =  (sqlparse.sql.Statement(parsed_rest_of_the_query[select_pos:]).value).strip()

        return [
            definition_query,
            intermediate_tables_query,
            table_query
        ]