
class SqlTable(object):

    def __init__(self, name="", type_=None):

        self.name=name
        
        self.type_=type_ # Permanent, Temporay, Intermediate
    
    def __repr__(self):

        return self.name