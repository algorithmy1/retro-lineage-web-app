from parser_agent.sql_query_part import QueryPart
from parser_agent.sql_query_miners import CreateQueryMiner
from parser_agent.sql_select_query import SelectQuery
from parser_agent.sql_table_id_generator import SqlTableIdGenerator


class CreateQueryIntermediates(QueryPart):

    def __init__(self, query_part, query_group_name="", output_table=""):

        super().__init__(query_part=query_part)

        self.queries_dict = None

        self.query_group_name = query_group_name

        self.output_table = output_table

    def mine(self):

        # Warning not tested

        self.queries_dict = CreateQueryMiner().mine_create_intermediate_tables_query(self.query_part)

        self.queries_as_objects = [SelectQuery(query, name, "INTERMEDIATE", final_output_table=self.output_table).mine() for name, query in self.queries_dict.items()] 

        return self
    
    def to_dash_elements(self,\
        with_parent=True):

        data = []
        parent=self.query_group_name

        for o in self.queries_as_objects:
            _id=""
            label=o.name
            query=o.query

            _id = SqlTableIdGenerator().generate(table_name=label, class_name="INTERMEDIATE", group_name=parent, output_table_name=self.output_table )

            _data = {
                        'id':_id,
                        'label':label,
                        'query':query
                    }
            
            if with_parent:
                _data['parent']=parent
            
            classes='INTERMEDIATE'

            data += [
                {
                    'data':_data,
                    'classes':classes
                }
            ]

            intermediate_tables = [x.upper() for x in  list(self.queries_dict.keys())]
            data+=o.to_dash_elements(with_parent=with_parent,\
                intermediate_tables= intermediate_tables,\
                query_group_name=self.query_group_name,\
                target_id=_id\
            )

        return data