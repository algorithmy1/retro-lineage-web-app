import moz_sql_parser

class SelectQueryParser(object):

    # Warning not tested

    def parse(self, query):

        return moz_sql_parser.parse(query)
    
    def list_wraper(self, value):

        if value is None:
        
            return []
        
        elif isinstance(value, list):
        
            return value
        
        else:
        
            return [value]
    
    def normalize(self, expression):

        # ensure parameters are in a list
        
        if not isinstance(expression, dict):
            return expression

        return {
            op: params
            for op, param in expression.items()
            for params in [[self.normalize(p) for p in self.list_wraper(param)]]
        }
    
    def parse_n_normalize(self, query):

        return self.normalize(self.parse(query))

