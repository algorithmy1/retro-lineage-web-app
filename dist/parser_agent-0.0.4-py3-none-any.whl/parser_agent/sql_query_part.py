
class QueryPart(object):

    def __init__(self, query_part, parent_query=""):

        self.query_part=query_part

        self.parent_query = parent_query